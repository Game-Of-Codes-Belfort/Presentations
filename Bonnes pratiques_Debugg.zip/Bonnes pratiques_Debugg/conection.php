<?php 


$bdd = new PDO ('mysql:host=localhost;dbname=manu_rav;charset=UTF8','root','');



 ?>