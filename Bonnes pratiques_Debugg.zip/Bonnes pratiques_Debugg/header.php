<?php 

function head($title,$fichier){



	echo "

	<!DOCTYPE html>
	<html lang='en'>
	<head>
	<meta charset='UTF-8'>
	<title>formu</title>
<link rel='stylesheet' href='$fichier.css'>
	</head>
	<body>
	<h1>$title</h1>

";



}



?>


